package com.jeu.users;

//Classe qui représente le dé :
public class De {
    protected String numero;



    public String getNumero() {
        return numero;
    }

    public  void setNumero(String numero) {
        numero = numero;
    }




}

